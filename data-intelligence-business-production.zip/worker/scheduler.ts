import {Queue} from 'bullmq';
import {env} from '../lib/env';
if(!env.REDIS_URL) throw new Error('REDIS_URL required');
const q=new Queue('dib-jobs',{connection:{url:env.REDIS_URL}});
await q.upsertJobScheduler('daily-opportunity-scan',{pattern:'0 9 * * *'},{name:'generate-opportunities',data:{}});
await q.upsertJobScheduler('daily-source-scan',{pattern:'0 8 * * *'},{name:'scan-sources',data:{query:'business procurement grants construction jobs'}});
console.log('scheduled daily discovery jobs');
