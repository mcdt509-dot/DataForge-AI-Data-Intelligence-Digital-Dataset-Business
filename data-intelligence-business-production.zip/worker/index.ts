import {Worker} from 'bullmq';import {env} from '../lib/env';import {scanDataGov} from '../lib/sources';
if(!env.REDIS_URL){console.error('REDIS_URL required for worker');process.exit(1)}
new Worker('dib-jobs',async job=>{switch(job.name){case 'scan-sources': return scanDataGov(job.data?.query||'business market');default: throw new Error(`Unknown job ${job.name}`)}},{connection:{url:env.REDIS_URL},concurrency:2}).on('failed',(job,err)=>console.error('job failed',job?.id,err));
console.log('DataForge worker online');
