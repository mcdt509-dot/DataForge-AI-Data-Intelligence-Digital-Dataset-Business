import {NextResponse} from 'next/server';
import {requireAdmin} from '@/lib/auth';import {db} from '@/lib/db';import {aiJson} from '@/lib/ai';import {csvBuffer,xlsxBuffer,pdfBuffer} from '@/lib/generators';import {putObject} from '@/lib/storage';

function normalizeRows(input:any):any[]{let rows:any[]=Array.isArray(input)?input:Array.isArray(input?.data)?input.data:[];const clean=rows.map(r=>{const o:any={};for(const [k,v] of Object.entries(r||{})){const key=String(k).trim().toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'');if(!key)continue;o[key]=typeof v==='string'?v.trim():v}return o}).filter(r=>Object.keys(r).length>0);const seen=new Set<string>();return clean.filter(r=>{const sig=JSON.stringify(r);if(seen.has(sig))return false;seen.add(sig);return true}).slice(0,100000)}

export async function POST(){
 try{
  const u=await requireAdmin();
  const ds=await db.dataset.findFirst({where:{status:'APPROVED',source:{allowedForResale:true,licenseStatus:'APPROVED'}},orderBy:{opportunityScore:'desc'},include:{source:true}});
  if(!ds)return NextResponse.json({error:'No legally approved dataset is ready. Approve a source and dataset first.'},{status:409});
  const res=await fetch(ds.sourceUrl,{headers:{accept:'application/json,text/csv,application/octet-stream'},cache:'no-store'});if(!res.ok)throw new Error(`Source returned ${res.status}`);
  const text=await res.text();let raw:any;try{raw=JSON.parse(text)}catch{raw=null}
  let rows=raw?normalizeRows(raw):[];if(!rows.length){const lines=text.split(/\r?\n/).filter(Boolean);if(lines.length){const headers=lines[0].split(',').map(x=>x.trim().replace(/^"|"$/g,''));rows=lines.slice(1).map(line=>{const vals=line.split(',');return Object.fromEntries(headers.map((h,i)=>[h,vals[i]?.replace(/^"|"$/g,'')||'']))}).slice(0,100000)}}
  if(!rows.length)throw new Error('No tabular records detected. Add a source-specific parser for this format.');
  const stats={rows:rows.length,fields:Object.keys(rows[0]||{}),nullRate:Object.fromEntries(Object.keys(rows[0]||{}).map(k=>[k,rows.filter(r=>r[k]===null||r[k]===undefined||r[k]==='').length/rows.length]))};
  const ai=await aiJson<any>('You are a data QA analyst. Never invent facts. Given dataset metadata, return JSON with title,description,methodology,limitations,recommendedBuyer,updateFrequency,priceCents,subscriptionPriceCents.','Source: '+JSON.stringify({name:ds.name,url:ds.sourceUrl,license:ds.licenseName,stats}));
  const slug=(ai.title||ds.name).toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')+'-'+Date.now();
  const csv=await csvBuffer(rows),xlsx=await xlsxBuffer(rows),pdf=await pdfBuffer(ai.title||ds.name,`Rows: ${rows.length}\nFields: ${stats.fields.join(', ')}\nSource: ${ds.sourceUrl}\nLicense: ${ds.licenseName||'See source terms'}\nMethodology: ${ai.methodology||''}\nLimitations: ${ai.limitations||''}`);
  const prefix=`products/${slug}`;const keys=[{key:`${prefix}/dataset.csv`,type:'text/csv'},{key:`${prefix}/dataset.xlsx`,type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'},{key:`${prefix}/report.pdf`,type:'application/pdf'}];
  await Promise.all([putObject(keys[0].key,csv,keys[0].type),putObject(keys[1].key,xlsx,keys[1].type),putObject(keys[2].key,pdf,keys[2].type)]);
  const p=await db.product.create({data:{datasetId:ds.id,slug,title:ai.title||ds.name,description:ai.description||ds.description||'Curated business intelligence dataset.',methodology:ai.methodology,usageInfo:`Source attribution: ${ds.sourceUrl}. License: ${ds.licenseName||'Review source license.'}`,limitations:ai.limitations,recommendedBuyer:ai.recommendedBuyer,updateFrequency:ai.updateFrequency,priceCents:Number(ai.priceCents)||4900,subscriptionPriceCents:ai.subscriptionPriceCents?Number(ai.subscriptionPriceCents):null,status:'DRAFT',sampleJson:rows.slice(0,10),fileKeys:keys}});
  await db.dataset.update({where:{id:ds.id},data:{rowCount:rows.length,qualityScore:Math.round((1-Object.values(stats.nullRate).reduce((a:any,b:any)=>a+Number(b),0)/Math.max(1,stats.fields.length))*100)}});
  await db.auditLog.create({data:{actorId:u.id,action:'BUILD_DATASET_PRODUCT',entityType:'Product',entityId:p.id,metadata:{datasetId:ds.id,rowCount:rows.length}}});
  return NextResponse.redirect(new URL('/admin',process.env.NEXT_PUBLIC_APP_URL));
 }catch(e){return NextResponse.json({error:String(e)},{status:500})}
}
