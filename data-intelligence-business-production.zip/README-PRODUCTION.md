# DataForge production launch

## Fastest real deployment: Docker

Requirements: Docker Engine/Desktop, a domain, HTTPS reverse proxy/WAF, and credentials for the services you actually enable.

1. Copy `.env.example` to `.env`.
2. Replace every `CHANGE_ME...` value and configure the production integrations.
3. For the bundled PostgreSQL container, keep `DATABASE_URL` pointed at `postgres`. For managed PostgreSQL, replace it with the provider's production connection string.
4. Start everything:

```powershell
./scripts/deploy.ps1
```

or:

```bash
docker compose -f docker-compose.prod.yml up -d --build
```

5. Put the web service behind HTTPS. The application itself listens on port 3000.
6. Verify `/api/health` returns `ok: true`.

## Stripe

Create a Stripe webhook endpoint at:

`https://YOUR_DOMAIN/api/webhooks/stripe`

Use the webhook signing secret as `STRIPE_WEBHOOK_SECRET`. Never expose the Stripe secret key to browser code.

## AI

Set `OPENAI_API_KEY` and optionally `OPENAI_BASE_URL`/`OPENAI_MODEL`. The AI layer is optional for basic storefront operation but required for automated opportunity/product generation.

## Object storage

Configure an S3-compatible bucket and keep it private. Paid files are accessed through the authenticated application. For high volume, replace direct server streaming with short-lived signed URLs.

## Email

Configure SMTP credentials and a sender address before enabling transactional/marketing email. Add unsubscribe handling for marketing messages.

## Legal/data controls

Never mark a source approved merely because it is publicly reachable. Keep evidence for the license/terms and confirm commercial resale rights for each source. The source approval gate is intentionally human-controlled.

## Production operations checklist

- HTTPS/WAF and DNS
- Managed PostgreSQL with backups/PITR for serious production traffic
- Redis persistence/HA if jobs are business-critical
- Private object storage and lifecycle policies
- Secret manager instead of committed `.env`
- Stripe live-mode account and webhook
- Transactional email provider
- Monitoring, alerting and log retention
- Tested backup restore
- Tax/VAT configuration where required
- Privacy policy, terms, refund policy and data-license disclosures
- Human review of AI-generated claims, legal status and pricing

## Managed Prisma alternative

Prisma currently documents Prisma Postgres as a managed PostgreSQL option with connection pooling and backups, and Prisma Compute as a deployment option. See the official Prisma documentation before choosing that path. 
