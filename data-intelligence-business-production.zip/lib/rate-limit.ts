const buckets=new Map<string,{n:number,t:number}>();
export function rateLimit(key:string,limit=60,windowMs=60_000){const now=Date.now();const b=buckets.get(key);if(!b||now-b.t>windowMs){buckets.set(key,{n:1,t:now});return true}if(b.n>=limit)return false;b.n++;return true}
