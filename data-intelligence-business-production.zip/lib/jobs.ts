import {Queue} from 'bullmq';import {env} from './env';
export const queue=env.REDIS_URL?new Queue('dib-jobs',{connection:{url:env.REDIS_URL}}):null;
export async function enqueue(name:string,data:any){if(!queue)throw new Error('REDIS_URL is not configured');return queue.add(name,data,{removeOnComplete:100,removeOnFail:100})}
