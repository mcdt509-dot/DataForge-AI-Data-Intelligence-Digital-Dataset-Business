import {S3Client,PutObjectCommand,GetObjectCommand} from '@aws-sdk/client-s3';
import {env} from './env';
const enabled=!!(env.S3_ENDPOINT&&env.S3_BUCKET&&env.S3_ACCESS_KEY_ID&&env.S3_SECRET_ACCESS_KEY);
const s3=enabled?new S3Client({region:env.S3_REGION,endpoint:env.S3_ENDPOINT,forcePathStyle:true,credentials:{accessKeyId:env.S3_ACCESS_KEY_ID!,secretAccessKey:env.S3_SECRET_ACCESS_KEY!}}):null;
export async function putObject(key:string,body:Buffer|string,contentType:string){if(!s3)throw new Error('S3 storage is not configured');await s3.send(new PutObjectCommand({Bucket:env.S3_BUCKET!,Key:key,Body:body,ContentType:contentType}));return key}
export async function getObject(key:string){if(!s3)throw new Error('S3 storage is not configured');return s3.send(new GetObjectCommand({Bucket:env.S3_BUCKET!,Key:key}))}
