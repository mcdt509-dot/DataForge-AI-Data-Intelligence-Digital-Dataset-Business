import OpenAI from 'openai';import {env} from './env';
const client=env.OPENAI_API_KEY?new OpenAI({apiKey:env.OPENAI_API_KEY,baseURL:env.OPENAI_BASE_URL}):null;
export async function aiJson<T>(system:string,user:string):Promise<T>{if(!client)throw new Error('AI provider not configured');const r=await client.chat.completions.create({model:env.OPENAI_MODEL,messages:[{role:'system',content:system},{role:'user',content:user}],response_format:{type:'json_object'}});return JSON.parse(r.choices[0]?.message?.content||'{}') as T}
