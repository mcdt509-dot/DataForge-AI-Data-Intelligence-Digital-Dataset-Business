import { cookies } from 'next/headers';
import bcrypt from 'bcryptjs';
import { SignJWT, jwtVerify } from 'jose';
import { db } from './db';
import { env } from './env';
const secret=new TextEncoder().encode(env.SESSION_SECRET);
export async function hashPassword(p:string){return bcrypt.hash(p,12)}
export async function verifyPassword(p:string,h:string){return bcrypt.compare(p,h)}
export async function createSession(userId:string){const token=await new SignJWT({sub:userId}).setProtectedHeader({alg:'HS256'}).setIssuedAt().setExpirationTime('7d').sign(secret);(await cookies()).set('dib_session',token,{httpOnly:true,secure:process.env.NODE_ENV==='production',sameSite:'lax',path:'/',maxAge:604800})}
export async function getSessionUser(){const token=(await cookies()).get('dib_session')?.value;if(!token)return null;try{const {payload}=await jwtVerify(token,secret);if(!payload.sub)return null;return db.user.findUnique({where:{id:String(payload.sub)}})}catch{return null}}
export async function requireAdmin(){const u=await getSessionUser();if(!u||u.role!=='ADMIN')throw new Error('UNAUTHORIZED');return u}
