import { z } from 'zod';
export const env = z.object({
 DATABASE_URL:z.string().min(1), SESSION_SECRET:z.string().min(32),
 STRIPE_SECRET_KEY:z.string().optional(), STRIPE_WEBHOOK_SECRET:z.string().optional(),
 NEXT_PUBLIC_APP_URL:z.string().url().default('http://localhost:3000'),
 OPENAI_API_KEY:z.string().optional(), OPENAI_BASE_URL:z.string().url().optional(), OPENAI_MODEL:z.string().default('gpt-5-mini'),
 REDIS_URL:z.string().optional(), S3_ENDPOINT:z.string().url().optional(), S3_REGION:z.string().default('us-east-1'), S3_BUCKET:z.string().optional(), S3_ACCESS_KEY_ID:z.string().optional(), S3_SECRET_ACCESS_KEY:z.string().optional(),
 SMTP_HOST:z.string().optional(), SMTP_PORT:z.coerce.number().default(587), SMTP_USER:z.string().optional(), SMTP_PASS:z.string().optional(), FROM_EMAIL:z.string().email().optional(),
 ADMIN_EMAIL:z.string().email(), ADMIN_PASSWORD:z.string().min(12)
}).parse(process.env);
