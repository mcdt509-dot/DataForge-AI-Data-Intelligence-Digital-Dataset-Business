$ErrorActionPreference='Stop'
if (!(Test-Path .env)) { Copy-Item .env.example .env }
npm install
npx prisma generate
npx prisma migrate dev --name init
npm run db:seed
Write-Host 'DataForge is ready. Start web with: npm run dev'
Write-Host 'Start worker with: npm run worker'
