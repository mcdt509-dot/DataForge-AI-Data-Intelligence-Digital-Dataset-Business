$ErrorActionPreference = 'Stop'
if (!(Test-Path .env)) { Copy-Item .env.example .env; Write-Host 'Created .env. Fill production secrets, then rerun.'; exit 1 }
Write-Host 'Building production images...'
docker compose -f docker-compose.prod.yml build
Write-Host 'Starting production stack...'
docker compose -f docker-compose.prod.yml up -d
Write-Host 'Running database seed...'
docker compose -f docker-compose.prod.yml exec web npm run db:seed
Write-Host 'Health check:'
Invoke-RestMethod http://localhost:3000/api/health
